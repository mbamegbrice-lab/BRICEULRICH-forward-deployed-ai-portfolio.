# Forward Deployed AI Engineer Portfolio

Three end-to-end projects, each modeled on a real customer engagement pattern. Every one runs **offline with no API key** (deterministic baseline) and upgrades to Claude when `ANTHROPIC_API_KEY` is set, so you can measure the lift instead of asserting it.

| # | Project | Customer problem | What it demonstrates |
|---|---------|------------------|----------------------|
| 1 | [`01-ticket-triage`](01-ticket-triage) | Support inbox is a mess; humans sort tickets by hand | Structured extraction, schema validation, retries, human escalation, **labeled eval set with held-out hard cases** |
| 2 | [`02-grounded-docs-qa`](02-grounded-docs-qa) | "Chatbot over our docs" that must never make things up | Chunking, BM25 retrieval, citations, **abstention**, hit@k + false-abstain evals, FastAPI service |
| 3 | [`03-refund-ops-agent`](03-refund-ops-agent) | Let an agent act on a system of record safely | Tool use, **guardrails in code not prompts**, human approval queue, audit log, dry-run mode |

## Run everything
```bash
for p in 01-ticket-triage 02-grounded-docs-qa 03-refund-ops-agent; do
  (cd $p && pip install -r requirements.txt && python -m pytest -q)
done
```
Set `ANTHROPIC_API_KEY` to switch from the offline baseline to Claude. Models are overridable via env vars (`TRIAGE_MODEL`, `QA_MODEL`, `AGENT_MODEL`).

## Principles these projects encode
1. **Evals before prompts.** Each project ships a measurable score you can diff in git.
2. **Never trust model output.** Validate, retry, then fail toward a human.
3. **Policy lives in code.** The model proposes; deterministic code disposes.
4. **Abstain over hallucinate.** Honest "I don't know" preserves customer trust.
5. **Ship a baseline first.** You can't claim an LLM helped without something to beat.
