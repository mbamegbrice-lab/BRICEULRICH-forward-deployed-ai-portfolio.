from fastapi import FastAPI
from pydantic import BaseModel

from .answer import answer

app = FastAPI(title="Grounded Docs QA")


class Ask(BaseModel):
    question: str


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/ask")
def ask(body: Ask):
    return answer(body.question)
