"""Grounded answering: retrieve -> abstain if weak evidence -> answer with citations.

FDE lesson: 'I don't know' is a feature. Customers lose trust after one confident
wrong answer far faster than after ten honest abstentions.
"""
import os
import re
from pathlib import Path

from .index import BM25, load_chunks

DOCS = Path(__file__).resolve().parent.parent / "data/docs"
MODEL = os.getenv("QA_MODEL", "claude-sonnet-5-5")
MIN_SCORE = float(os.getenv("QA_MIN_SCORE", "2.5"))
ABSTAIN = "I couldn't find that in the documentation. Please contact support."

_index = None


def get_index() -> BM25:
    global _index
    if _index is None:
        _index = BM25(load_chunks(DOCS))
    return _index


def _llm_answer(question: str, hits) -> str:
    import anthropic

    context = "\n\n".join(f"[{c.id}] {c.text}" for c, _ in hits)
    resp = anthropic.Anthropic().messages.create(
        model=MODEL,
        max_tokens=400,
        system="Answer ONLY from the provided context. Cite chunk ids like [doc#n] after each claim. "
        f"If the context does not contain the answer, reply exactly: {ABSTAIN}",
        messages=[{"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"}],
    )
    return "".join(b.text for b in resp.content if b.type == "text")


def _extractive_answer(question: str, hits) -> str:
    chunk = hits[0][0]
    return f"{chunk.text.split(': ', 1)[1]} [{chunk.id}]"


def answer(question: str, k: int = 3) -> dict:
    hits = get_index().search(question, k)
    top_score = hits[0][1]
    sources = [{"id": c.id, "score": round(s, 2)} for c, s in hits]
    if top_score < MIN_SCORE:
        return {"answer": ABSTAIN, "abstained": True, "sources": sources}
    text = _llm_answer(question, hits) if os.getenv("ANTHROPIC_API_KEY") else _extractive_answer(question, hits)
    cited = set(re.findall(r"\[([\w]+#\d+)\]", text))
    return {"answer": text, "abstained": text.strip() == ABSTAIN, "sources": sources, "cited": sorted(cited)}
