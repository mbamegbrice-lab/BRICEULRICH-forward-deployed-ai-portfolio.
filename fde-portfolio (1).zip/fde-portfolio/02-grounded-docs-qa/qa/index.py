"""Chunking + a dependency-free BM25 index. Chunks keep doc + heading for citations."""
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

STOP = set("a an the of to in is are and or for on at by be with as it we our you your do does can may this that from".split())


def tokenize(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9\.]+", text.lower()) if t not in STOP]


@dataclass
class Chunk:
    id: str
    doc: str
    text: str


def load_chunks(doc_dir: Path) -> list[Chunk]:
    chunks = []
    for path in sorted(Path(doc_dir).glob("*.md")):
        title, *paras = [p.strip() for p in path.read_text().split("\n\n") if p.strip()]
        for i, para in enumerate(paras):
            chunks.append(Chunk(id=f"{path.stem}#{i}", doc=path.stem, text=f"{title.lstrip('# ')}: {para}"))
    return chunks


class BM25:
    def __init__(self, chunks: list[Chunk], k1: float = 1.5, b: float = 0.75):
        self.chunks, self.k1, self.b = chunks, k1, b
        self.tf = [Counter(tokenize(c.text)) for c in chunks]
        self.len = [sum(t.values()) for t in self.tf]
        self.avg = sum(self.len) / len(self.len)
        df = Counter(w for t in self.tf for w in t)
        n = len(chunks)
        self.idf = {w: math.log(1 + (n - d + 0.5) / (d + 0.5)) for w, d in df.items()}

    def search(self, query: str, k: int = 3) -> list[tuple[Chunk, float]]:
        q = tokenize(query)
        scored = []
        for i, c in enumerate(self.chunks):
            s = 0.0
            for w in q:
                f = self.tf[i].get(w, 0)
                if f:
                    s += self.idf[w] * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * self.len[i] / self.avg))
            scored.append((c, s))
        return sorted(scored, key=lambda x: -x[1])[:k]
