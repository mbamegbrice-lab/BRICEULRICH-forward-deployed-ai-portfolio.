# 02 · Grounded Docs Q&A (RAG with abstention)

**Scenario.** A customer wants a support assistant over their policy docs. Their one hard requirement: *it must not invent policy.*

## Architecture
```
docs/*.md -> paragraph chunks (id = doc#n) -> BM25 index
question -> top-k -> score < threshold? -> abstain
                  -> else LLM answers ONLY from context with [doc#n] citations
```
Retrieval is a dependency-free BM25 on purpose: it's a strong baseline, debuggable, and shows retrieval is measured separately from generation.

## Run
```bash
pip install -r requirements.txt
python -m pytest -q
python -m evals.run_eval
uvicorn qa.api:app --reload      # POST /ask {"question": "..."}
```

## Results (offline)
hit@3 = 100%, correct abstention on unanswerable questions = 100%, **false-abstain rate = 20%** (it refuses 2 of 10 answerable questions). That's the core tradeoff: tune `QA_MIN_SCORE` and watch the two error types move in opposite directions. Next step: swap in embeddings or hybrid search and re-run the eval.

## Ideas to extend
- Hybrid BM25 + embeddings with reranking.
- Citation verification: check each cited chunk actually supports the claim.
- Feedback endpoint that turns thumbs-down into new eval cases.
