# Security Overview

All customer data is encrypted at rest using AES-256 and in transit using TLS 1.2 or higher.

We are SOC 2 Type II certified. Audit reports are available to customers under NDA.

Customer data is stored in the US region by default. EU data residency is available on the Enterprise plan.

Employee access to production systems requires hardware-key two-factor authentication and is logged and reviewed quarterly.

Security incidents affecting customer data are reported to affected customers within 72 hours of confirmation.
