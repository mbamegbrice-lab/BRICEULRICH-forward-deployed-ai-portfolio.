# Refund Policy

Customers on monthly plans may request a refund within 14 days of a charge. Annual plans may be refunded within 30 days of purchase.

After the refund window closes, we do not issue refunds, but customers may cancel to stop future charges.

Refunds are returned to the original payment method and take 5 to 10 business days to appear.

Enterprise contracts are governed by the order form and are not covered by this policy.
