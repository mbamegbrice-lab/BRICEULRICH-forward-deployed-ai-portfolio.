# Service Level Agreement

The platform commits to 99.9 percent monthly uptime for Pro and Enterprise plans.

If monthly uptime falls below 99.9 percent, customers receive a service credit of 10 percent of that month's fee. Below 99 percent, the credit is 25 percent.

Support response times: Enterprise customers receive a first response within 1 hour for severity 1 issues. Pro customers receive a first response within 8 business hours.

Scheduled maintenance is announced at least 5 days in advance and does not count against uptime.
