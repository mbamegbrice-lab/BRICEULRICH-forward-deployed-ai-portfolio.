from fastapi.testclient import TestClient

from qa.answer import ABSTAIN, answer
from qa.api import app


def test_answers_with_citation(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    res = answer("How long do I have to get a refund on a monthly plan?")
    assert not res["abstained"]
    assert "refund_policy#0" in res["cited"]


def test_abstains_when_unsupported(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    res = answer("Who is your CEO?")
    assert res["abstained"] and res["answer"] == ABSTAIN


def test_api_roundtrip(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    r = TestClient(app).post("/ask", json={"question": "Are you SOC 2 certified?"})
    assert r.status_code == 200 and "security_policy#1" in r.json()["cited"]
