"""Retrieval hit@k + abstention quality. Usage: python -m evals.run_eval"""
import json
from pathlib import Path

from qa.answer import answer, get_index

ROOT = Path(__file__).resolve().parent


def main() -> dict:
    rows = [json.loads(l) for l in (ROOT / "questions.jsonl").read_text().splitlines() if l]
    idx = get_index()
    hit = ans_total = abst_ok = unans_total = false_abstain = 0
    failures = []
    for r in rows:
        res = answer(r["q"])
        if r["answerable"]:
            ans_total += 1
            ids = [c.id for c, _ in idx.search(r["q"], 3)]
            if r["expect_chunk"] in ids:
                hit += 1
            else:
                failures.append(f"retrieval miss: {r['q']}")
            if res["abstained"]:
                false_abstain += 1
                failures.append(f"wrongly abstained: {r['q']}")
        else:
            unans_total += 1
            if res["abstained"]:
                abst_ok += 1
            else:
                failures.append(f"hallucination risk (should abstain): {r['q']}")
    m = {
        "hit_at_3": hit / ans_total,
        "false_abstain_rate": false_abstain / ans_total,
        "correct_abstain_rate": abst_ok / unans_total,
    }
    print(json.dumps({k: round(v, 2) for k, v in m.items()}))
    for f in failures:
        print(" -", f)
    return m


if __name__ == "__main__":
    main()
