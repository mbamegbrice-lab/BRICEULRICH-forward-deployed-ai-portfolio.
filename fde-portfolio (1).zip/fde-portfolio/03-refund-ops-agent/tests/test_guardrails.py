import pytest

from agent.db import connect
from agent.loop import run
from agent.tools import Tools


@pytest.fixture
def tools():
    return Tools(connect())


def test_small_in_window_refund_succeeds(tools):
    assert tools.issue_refund(1002, 50, "damaged")["status"] == "refunded"


def test_cannot_refund_more_than_remaining(tools):
    tools.issue_refund(1001, 40, "x")
    assert tools.issue_refund(1001, 40, "x")["why"] == "amount_exceeds_refundable"


def test_outside_window_rejected(tools):
    assert tools.issue_refund(1004, 10, "x")["why"].startswith("outside_")


def test_large_refund_requires_human_approval(tools):
    out = tools.issue_refund(1003, 500, "x")
    assert out["status"] == "pending_approval"
    assert tools.con.execute("SELECT refunded FROM orders WHERE id=1003").fetchone()[0] == 0
    assert tools.con.execute("SELECT COUNT(*) FROM approvals").fetchone()[0] == 1


def test_dry_run_changes_nothing():
    t = Tools(connect(), dry_run=True)
    assert t.issue_refund(1001, 10, "x")["status"] == "dry_run_ok"
    assert t.con.execute("SELECT refunded FROM orders WHERE id=1001").fetchone()[0] == 0


def test_every_call_is_audited(tools):
    tools.lookup_order(1001)
    tools.issue_refund(9999, 1, "x")
    assert tools.con.execute("SELECT COUNT(*) FROM audit").fetchone()[0] == 2


def test_bad_tool_args_do_not_crash(tools):
    assert "error" in tools.dispatch("issue_refund", {"order_id": 1001})


def test_scripted_agent_end_to_end(tools, monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert "pending_approval" in run("Refund order 1003 fully please", tools)
