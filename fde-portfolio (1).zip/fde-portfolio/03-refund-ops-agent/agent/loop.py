"""Agent loop. Claude tool-use when ANTHROPIC_API_KEY is set; otherwise a scripted planner
so demos, tests and CI run offline. Either way, all side effects go through Tools."""
import json
import os
import re

from .tools import TOOL_SPECS, Tools

MODEL = os.getenv("AGENT_MODEL", "claude-sonnet-5-5")
MAX_STEPS = 6
SYSTEM = """You are a customer-support operations agent. Resolve refund requests using the tools.
Always look up the order first. Request only what the customer is owed. If a tool rejects or
escalates, do NOT retry with workarounds; explain the outcome plainly. Be brief."""


def run(request: str, tools: Tools) -> str:
    if os.getenv("ANTHROPIC_API_KEY"):
        return _run_claude(request, tools)
    return _run_scripted(request, tools)


def _run_claude(request: str, tools: Tools) -> str:
    import anthropic

    client = anthropic.Anthropic()
    messages = [{"role": "user", "content": request}]
    for _ in range(MAX_STEPS):
        resp = client.messages.create(model=MODEL, max_tokens=1024, system=SYSTEM,
                                      tools=TOOL_SPECS, messages=messages)
        messages.append({"role": "assistant", "content": resp.content})
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")
        results = [
            {"type": "tool_result", "tool_use_id": b.id, "content": json.dumps(tools.dispatch(b.name, b.input))}
            for b in resp.content if b.type == "tool_use"
        ]
        messages.append({"role": "user", "content": results})
    return "Stopped: step limit reached; escalating to a human."


def _run_scripted(request: str, tools: Tools) -> str:
    m = re.search(r"\b(\d{4})\b", request)
    if not m:
        return "I need an order number to proceed."
    order = tools.lookup_order(int(m.group(1)))
    if "error" in order:
        return f"I couldn't find order {m.group(1)}."
    amt = re.search(r"\$(\d+(?:\.\d+)?)", request)
    amount = float(amt.group(1)) if amt else order["total"] - order["refunded"]
    out = tools.issue_refund(order["id"], amount, "customer request")
    return f"Order {order['id']}: {out['status']}" + (f" ({out['why']})" if "why" in out else "")
