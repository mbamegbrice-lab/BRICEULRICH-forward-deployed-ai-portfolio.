"""Mock customer system of record (SQLite). In a real engagement this is their ERP/OMS API."""
import sqlite3
from datetime import date, timedelta


def connect(path: str = ":memory:") -> sqlite3.Connection:
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, customer TEXT, total REAL,
            placed_on TEXT, refunded REAL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, tool TEXT,
            args TEXT, outcome TEXT, ts TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS approvals(id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER,
            amount REAL, reason TEXT, status TEXT DEFAULT 'pending');
        """
    )
    if not con.execute("SELECT 1 FROM orders").fetchone():
        today = date.today()
        seed = [
            (1001, "ada@example.com", 49.0, today - timedelta(days=5)),
            (1002, "bo@example.com", 120.0, today - timedelta(days=12)),
            (1003, "cy@example.com", 899.0, today - timedelta(days=9)),
            (1004, "di@example.com", 59.0, today - timedelta(days=90)),
        ]
        con.executemany("INSERT INTO orders(id,customer,total,placed_on) VALUES (?,?,?,?)",
                        [(i, c, t, d.isoformat()) for i, c, t, d in seed])
        con.commit()
    return con
