import sys

from .db import connect
from .loop import run
from .tools import Tools

if __name__ == "__main__":
    con = connect()
    request = " ".join(sys.argv[1:]) or "Please refund order 1002, it arrived damaged."
    print(run(request, Tools(con)))
    print("\nAudit trail:")
    for r in con.execute("SELECT tool, args, outcome FROM audit"):
        print(" ", r["tool"], r["args"], "->", r["outcome"])
