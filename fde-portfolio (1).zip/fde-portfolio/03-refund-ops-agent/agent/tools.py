"""Tools with guardrails enforced IN CODE, not in the prompt.

Prompts are suggestions; code is policy. Every call is audit-logged, and anything over
the auto-approve limit becomes a pending approval for a human instead of a refund.
"""
import json
from datetime import date

REFUND_WINDOW_DAYS = 30
AUTO_APPROVE_LIMIT = 200.0


class Tools:
    def __init__(self, con, dry_run: bool = False):
        self.con, self.dry_run = con, dry_run

    def _log(self, tool, args, outcome):
        self.con.execute("INSERT INTO audit(tool,args,outcome) VALUES (?,?,?)",
                         (tool, json.dumps(args), json.dumps(outcome)))
        self.con.commit()
        return outcome

    def lookup_order(self, order_id: int) -> dict:
        row = self.con.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        out = dict(row) if row else {"error": "order_not_found"}
        return self._log("lookup_order", {"order_id": order_id}, out)

    def issue_refund(self, order_id: int, amount: float, reason: str) -> dict:
        args = {"order_id": order_id, "amount": amount, "reason": reason}
        row = self.con.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not row:
            return self._log("issue_refund", args, {"status": "rejected", "why": "order_not_found"})
        if amount <= 0 or amount > row["total"] - row["refunded"]:
            return self._log("issue_refund", args, {"status": "rejected", "why": "amount_exceeds_refundable"})
        age = (date.today() - date.fromisoformat(row["placed_on"])).days
        if age > REFUND_WINDOW_DAYS:
            return self._log("issue_refund", args, {"status": "rejected", "why": f"outside_{REFUND_WINDOW_DAYS}_day_window"})
        if amount > AUTO_APPROVE_LIMIT:
            self.con.execute("INSERT INTO approvals(order_id,amount,reason) VALUES (?,?,?)", (order_id, amount, reason))
            self.con.commit()
            return self._log("issue_refund", args, {"status": "pending_approval", "why": "over_auto_approve_limit"})
        if self.dry_run:
            return self._log("issue_refund", args, {"status": "dry_run_ok"})
        self.con.execute("UPDATE orders SET refunded=refunded+? WHERE id=?", (amount, order_id))
        self.con.commit()
        return self._log("issue_refund", args, {"status": "refunded", "amount": amount})

    def dispatch(self, name: str, args: dict) -> dict:
        fn = {"lookup_order": self.lookup_order, "issue_refund": self.issue_refund}.get(name)
        if not fn:
            return {"error": f"unknown_tool:{name}"}
        try:
            return fn(**args)
        except TypeError as e:  # model passed bad arguments
            return {"error": f"bad_arguments:{e}"}


TOOL_SPECS = [
    {
        "name": "lookup_order",
        "description": "Fetch an order by id: total, date, amount already refunded.",
        "input_schema": {"type": "object", "properties": {"order_id": {"type": "integer"}}, "required": ["order_id"]},
    },
    {
        "name": "issue_refund",
        "description": "Refund part or all of an order. Policy is enforced server-side; the result tells you "
        "whether it was refunded, rejected, or sent for human approval.",
        "input_schema": {
            "type": "object",
            "properties": {
                "order_id": {"type": "integer"},
                "amount": {"type": "number"},
                "reason": {"type": "string"},
            },
            "required": ["order_id", "amount", "reason"],
        },
    },
]
