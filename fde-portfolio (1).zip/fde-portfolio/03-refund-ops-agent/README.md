# 03 · Refund Ops Agent with Guardrails

**Scenario.** A retailer wants an agent to process refund requests against their order system. The risk: a prompt-injected or confused model issuing large or invalid refunds.

## Architecture
```
request -> agent loop (Claude tool-use) -> Tools.dispatch -> guardrails -> SQLite "system of record"
                                                       \-> audit log (every call)
                                                       \-> approvals queue (> $200)
```
Guardrails live in `agent/tools.py`, not in the prompt: refund window (30d), cap at remaining refundable amount, human approval above $200, dry-run mode, bad-argument handling.

## Run
```bash
pip install -r requirements.txt
python -m pytest -q
python -m agent "Refund order 1003 please"      # shows result + audit trail
```
Works offline via a scripted planner; set `ANTHROPIC_API_KEY` for real Claude tool-use.

## Why it matters
Even if the model is jailbroken or wrong, the worst case is a row in the approvals queue. The tests prove the invariants hold independent of any model.

## Ideas to extend
- Replace SQLite with a real REST API client + retries/idempotency keys.
- Add a prompt-injection test set (malicious text inside order notes) as an eval.
- Add an approvals UI/endpoint and Slack notification.
