import json

from triage import pipeline
from triage.schema import Category


def _out(**kw):
    base = {"category": "bug", "priority": "high", "confidence": 0.9, "needs_human": False, "summary": "x"}
    return json.dumps({**base, **kw})


def test_valid_output_passes(monkeypatch):
    monkeypatch.setattr(pipeline, "complete", lambda p: _out())
    assert pipeline.triage_ticket("boom").category == Category.bug


def test_retries_on_garbage_then_succeeds(monkeypatch):
    calls = iter(["not json", '{"category": "nope"}', _out(category="billing")])
    monkeypatch.setattr(pipeline, "complete", lambda p: next(calls))
    assert pipeline.triage_ticket("t").category == Category.billing


def test_falls_back_to_human_after_repeated_failure(monkeypatch):
    monkeypatch.setattr(pipeline, "complete", lambda p: "garbage")
    out = pipeline.triage_ticket("t")
    assert out.needs_human and out.confidence == 0


def test_low_confidence_escalates(monkeypatch):
    monkeypatch.setattr(pipeline, "complete", lambda p: _out(confidence=0.2))
    assert pipeline.triage_ticket("t").needs_human
