from enum import Enum
from pydantic import BaseModel, Field


class Category(str, Enum):
    billing = "billing"
    bug = "bug"
    access = "access"
    feature_request = "feature_request"
    other = "other"


class Priority(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"
    urgent = "urgent"


class Triage(BaseModel):
    category: Category
    priority: Priority
    confidence: float = Field(ge=0, le=1)
    needs_human: bool = False
    summary: str = Field(max_length=200)
