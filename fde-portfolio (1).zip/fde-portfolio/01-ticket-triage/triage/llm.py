"""LLM access with an offline heuristic baseline.

With ANTHROPIC_API_KEY set, calls Claude. Without it, a keyword baseline runs so the
whole project (tests, evals, CI) works offline -- and gives you a baseline to beat.
"""
import json
import os
import re

MODEL = os.getenv("TRIAGE_MODEL", "claude-sonnet-5-5")

SYSTEM = """You triage inbound customer support tickets.
Return ONLY a JSON object with keys:
category (billing|bug|access|feature_request|other),
priority (low|medium|high|urgent),
confidence (0-1, your honest certainty),
needs_human (true if ambiguous, legally sensitive, or an angry customer),
summary (<=200 chars).
Urgent = production down, data loss, or a hard deadline. No prose, no markdown."""


def complete(user: str, system: str = SYSTEM) -> str:
    if os.getenv("ANTHROPIC_API_KEY"):
        import anthropic

        client = anthropic.Anthropic()
        resp = client.messages.create(
            model=MODEL,
            max_tokens=400,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(b.text for b in resp.content if b.type == "text")
    return _heuristic(user)


_CAT = [
    ("access", r"log ?in|password|locked out|two-factor|2fa|admin access"),
    ("billing", r"charged|invoice|refund|billing|card|vat|payment|cancel"),
    ("feature_request", r"would be great|please add|could you add|feature"),
    ("bug", r"error|crash|500|503|slow|broken|bug|typo|dropping|sync"),
]
_PRI = [
    ("urgent", r"urgent|asap|production|all requests|losing|locked out|missing rows"),
    ("high", r"charged twice|crash|error|can't|declined|not being accepted|never arrives"),
    ("medium", r"invoice|wrong|slow|admin access|cancel|sso"),
]


def _heuristic(text: str) -> str:
    t = text.split("Ticket:\n")[-1].split("\n\nYour last")[0].lower()
    cat = next((c for c, p in _CAT if re.search(p, t)), "other")
    pri = next((p for p, rx in _PRI if re.search(rx, t)), "low")
    conf = 0.8 if cat != "other" else 0.4
    return json.dumps(
        {"category": cat, "priority": pri, "confidence": conf, "needs_human": conf < 0.5, "summary": t[:200]}
    )
