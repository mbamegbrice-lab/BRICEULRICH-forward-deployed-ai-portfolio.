"""Triage pipeline: LLM call -> strict validation -> retry -> safe fallback.

FDE lesson: never trust model output. Validate it, retry with the error, and fail
toward a human rather than toward a wrong automated action.
"""
import json
import re

from pydantic import ValidationError

from .llm import complete
from .schema import Category, Priority, Triage

CONFIDENCE_FLOOR = 0.55
MAX_ATTEMPTS = 3


def _extract_json(raw: str) -> dict:
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        raise ValueError("no JSON object found")
    return json.loads(match.group(0))


def triage_ticket(text: str) -> Triage:
    prompt = f"Ticket:\n{text}"
    for _ in range(MAX_ATTEMPTS):
        raw = complete(prompt)
        try:
            result = Triage.model_validate(_extract_json(raw))
        except (ValueError, ValidationError) as err:
            prompt = f"Ticket:\n{text}\n\nYour last output was invalid ({err}). Return valid JSON only."
            continue
        if result.confidence < CONFIDENCE_FLOOR:
            result.needs_human = True
        return result
    return Triage(
        category=Category.other,
        priority=Priority.medium,
        confidence=0.0,
        needs_human=True,
        summary="Automated triage failed; routed to a human.",
    )
