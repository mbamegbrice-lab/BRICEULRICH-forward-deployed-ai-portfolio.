# Triage eval report

- Tickets: 28
- Category accuracy: 75%
- Priority accuracy: 79%
- Escalated to human: 32%

## Category confusions (true -> predicted)
- bug -> other: 3
- access -> other: 2
- billing -> other: 1
- feature_request -> other: 1

## Misses
- "We can't get into our workspace since this morning and nobody can reach the dashboard" | cat access->other | pri high->high
- "Your last update wiped our saved filters" | cat bug->other | pri medium->low
- "Why did my bill jump from $49 to $79 this month?" | cat billing->other | pri medium->low
- "Would love to see a Slack integration someday" | cat feature_request->other | pri low->low
- "Need to hand over account ownership to our new CTO" | cat access->other | pri medium->low
- "Checkout page spins forever on Safari" | cat bug->other | pri high->low
- "Sales promised a 20% discount and it is not on my invoice. I am furious." | cat billing->billing | pri high->medium
- "Everything is down. Our customers are screaming at us." | cat bug->other | pri urgent->low
