"""Run the labeled set through the pipeline and write evals/report.md.

Usage: python -m evals.run_eval
Compare runs (baseline vs. Claude, prompt v1 vs. v2) by diffing report.md in git.
"""
import json
from collections import Counter
from pathlib import Path

from triage.pipeline import triage_ticket

ROOT = Path(__file__).resolve().parent.parent


def main() -> dict:
    rows = [json.loads(l) for l in (ROOT / "data/tickets.jsonl").read_text().splitlines() if l]
    cat_ok = pri_ok = human = 0
    misses, confusion = [], Counter()
    for r in rows:
        out = triage_ticket(r["text"])
        cat_ok += out.category.value == r["category"]
        pri_ok += out.priority.value == r["priority"]
        human += out.needs_human
        if out.category.value != r["category"]:
            confusion[(r["category"], out.category.value)] += 1
        if out.category.value != r["category"] or out.priority.value != r["priority"]:
            misses.append((r["text"], r["category"], out.category.value, r["priority"], out.priority.value))
    n = len(rows)
    metrics = {"n": n, "category_acc": cat_ok / n, "priority_acc": pri_ok / n, "human_rate": human / n}
    lines = [
        "# Triage eval report",
        "",
        f"- Tickets: {n}",
        f"- Category accuracy: {metrics['category_acc']:.0%}",
        f"- Priority accuracy: {metrics['priority_acc']:.0%}",
        f"- Escalated to human: {metrics['human_rate']:.0%}",
        "",
        "## Category confusions (true -> predicted)",
        *[f"- {a} -> {b}: {c}" for (a, b), c in confusion.most_common()],
        "",
        "## Misses",
        *[f'- "{t}" | cat {c1}->{c2} | pri {p1}->{p2}' for t, c1, c2, p1, p2 in misses],
    ]
    (ROOT / "evals/report.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines[:7]))
    return metrics


if __name__ == "__main__":
    main()
