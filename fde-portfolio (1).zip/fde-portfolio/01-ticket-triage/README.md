# 01 · Support Ticket Triage with Evals

**Scenario.** A SaaS customer's support inbox gets ~2k tickets/week. Agents manually label category and priority, and urgent issues get buried. Goal: auto-triage, and route anything uncertain to a human.

## Architecture
```
ticket text -> LLM (JSON) -> pydantic validation -> retry w/ error feedback (x3)
            -> confidence floor -> needs_human flag -> fallback: human queue
```

## Run
```bash
pip install -r requirements.txt
python -m pytest -q          # validation / retry / fallback behavior
python -m evals.run_eval     # writes evals/report.md
```

## Results (offline keyword baseline)
Run on 28 tickets (20 in-distribution, 8 held-out paraphrases): **category 75%, priority 79%**. The baseline fails on the held-out set because it keys on exact words ("bill" vs "billing", "can't get into" vs "log in"). That's the gap an LLM should close.
**TODO for you:** run with `ANTHROPIC_API_KEY`, commit the new `evals/report.md`, and add your before/after numbers here.

## Ideas to extend
- Grow the eval set to 200+ real-style tickets; add per-class precision/recall.
- A/B two prompts and gate merges on eval regression in CI.
- Add cost/latency tracking per ticket.
